package edu.nobreza;

public class Rainha extends Nobre implements Diplomata{

    @Override
    public void fazerDiplomacia() {

    }

}
