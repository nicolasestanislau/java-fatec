package edu.nobreza;

public class Nobre {

    Soldado soldade = new Soldado();
    Conselheiro conselheiro = new Conselheiro();

    void governar() {
        System.out.println("governando");
    }
}
