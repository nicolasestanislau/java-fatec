package edu.nobreza;

public class Principe extends Nobre implements Cavaleiro  {

    @Override
    public void duelar() {

    }
}
