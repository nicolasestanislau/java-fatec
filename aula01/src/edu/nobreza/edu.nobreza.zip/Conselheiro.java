package edu.nobreza;

import java.util.ArrayList;
import java.util.List;

public class Conselheiro {

    public List<Bispo> bispo = new ArrayList<>();
}
