package edu.nobreza;

public interface Cavaleiro {

    public void duelar();
}
