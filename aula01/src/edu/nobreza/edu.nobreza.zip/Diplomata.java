package edu.nobreza;

public interface Diplomata {

    public void fazerDiplomacia();
}
