package edu.nobreza;

public interface Fiel {

    public void rezar();
}
