package edu.nobreza;

public class Conde extends Nobre{
}
