package edu.nobreza;

public class Padre {
}
